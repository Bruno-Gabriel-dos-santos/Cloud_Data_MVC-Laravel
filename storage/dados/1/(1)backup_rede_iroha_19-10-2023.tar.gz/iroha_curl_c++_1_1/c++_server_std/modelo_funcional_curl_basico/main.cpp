#include <iostream>
#include <string>
#include <curl/curl.h>

// Função de callback para escrever os dados recebidos pela requisição
size_t WriteCallback(void *contents, size_t size, size_t nmemb, std::string *output) {
    size_t totalSize = size * nmemb;
    output->append((char*)contents, totalSize);
    return totalSize;
}

int main() {
    // Inicialização do libcurl
    CURL *curl;
    CURLcode res;
    curl = curl_easy_init();
    
    if (curl) {
        // URL do endpoint para onde será enviada a requisição POST
        std::string url = "http://localhost/site_iroha/server.php";
        
        // Dados que serão enviados no corpo da requisição POST
        std::string postData = "param1=value1&param2=value2";
        
        // Configuração da requisição cURL
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
        
        // Armazena a resposta recebida em uma string
        std::string response;
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        
        // Executa a requisição
        res = curl_easy_perform(curl);
        
        // Verifica se a requisição foi bem-sucedida
        if (res != CURLE_OK) {
            std::cerr << "Erro na requisição cURL: " << curl_easy_strerror(res) << std::endl;
        } else {
            // Imprime a resposta recebida
            std::cout << "Resposta da requisição:\n" << response << std::endl;
        }
        
        // Limpa a instância do cURL e libera recursos
        curl_easy_cleanup(curl);
    } else {
        std::cerr << "Falha na inicialização do cURL." << std::endl;
    }
    
    return 0;
}