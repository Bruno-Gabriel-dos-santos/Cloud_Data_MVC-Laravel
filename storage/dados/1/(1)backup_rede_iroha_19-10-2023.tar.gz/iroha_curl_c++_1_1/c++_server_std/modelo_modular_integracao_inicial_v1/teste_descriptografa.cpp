#include <sodium.h>
#include <iostream>
#include <string>
#include <vector>

bool descriptografarTexto(const std::string& mensagemCriptografada, const std::string& nonceTexto, const std::string& chavePrivadaTexto, const std::string& chavePublicaTexto, std::string& mensagemDescriptografada) {
    if (sodium_init() < 0) {
        std::cerr << "Erro ao inicializar o libsodium." << std::endl;
        return false;
    }

    // Converter a chave privada, chave pública e nonce de texto para vetores de bytes
    std::vector<unsigned char> chavePrivada(crypto_box_SECRETKEYBYTES);
    std::vector<unsigned char> chavePublica(crypto_box_PUBLICKEYBYTES);
    std::vector<unsigned char> nonce(crypto_box_NONCEBYTES);

    if (sodium_hex2bin(chavePrivada.data(), chavePrivada.size(), chavePrivadaTexto.c_str(), chavePrivadaTexto.length(), nullptr, nullptr, nullptr) < 0 ||
        sodium_hex2bin(chavePublica.data(), chavePublica.size(), chavePublicaTexto.c_str(), chavePublicaTexto.length(), nullptr, nullptr, nullptr) < 0 ||
        sodium_hex2bin(nonce.data(), nonce.size(), nonceTexto.c_str(), nonceTexto.length(), nullptr, nullptr, nullptr) < 0) {
        std::cerr << "Erro ao converter chaves ou nonce de texto para bytes." << std::endl;
        return false;
    }

    // Buffer para a mensagem descriptografada
    std::vector<unsigned char> mensagemBuffer(mensagemCriptografada.size());

    // Descriptografar a mensagem usando a chave privada e pública
    if (crypto_box_open_easy(mensagemBuffer.data(), reinterpret_cast<const unsigned char*>(mensagemCriptografada.c_str()), mensagemCriptografada.size(), nonce.data(), chavePublica.data(), chavePrivada.data()) != 0) {
        std::cerr << "Erro ao descriptografar a mensagem." << std::endl;
        return false;
    }

    // Converter a mensagem descriptografada para uma string
    mensagemDescriptografada.assign(reinterpret_cast<char*>(mensagemBuffer.data()), mensagemBuffer.size());

    return true;
}

int main() {
    std::string mensagemCriptografada = "..."; // Substitua pela mensagem criptografada em formato de texto
    std::string nonceTexto = "0123456789abcdef0123456789abcdef"; // Substitua pelo nonce em formato de texto
    std::string chavePrivadaTexto = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"; // Substitua pela chave privada em formato de texto
    std::string chavePublicaTexto = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"; // Substitua pela chave pública em formato de texto
    std::string mensagemDescriptografada;

    if (descriptografarTexto(mensagemCriptografada, nonceTexto, chavePrivadaTexto, chavePublicaTexto, mensagemDescriptografada)) {
        std::cout << "Mensagem descriptografada: " << mensagemDescriptografada << std::endl;
    } else {
        std::cerr << "Falha ao descriptografar a mensagem." << std::endl;
    }

    return 0;
}
