#include <iostream>
#include <vector>
#include <string>
#include <fstream>

std::vector<std::string> ler(std::string nome_do_arquivo){
    static std::vector<std::string> dados;dados.clear();

    std::string nomeArquivo=nome_do_arquivo;
    std::ifstream arquivo(nomeArquivo);

    if (!arquivo.is_open()) {
        std::cerr << "Erro ao abrir o arquivo." << std::endl;
        return;
    }

    std::string linha;
    while (std::getline(arquivo, linha)) {
        dados.push_back(linha);
    }

    arquivo.close();
    return dados;
}

std::vector<std::string> gravar(const std::string& nomeArquivo, const std::vector<std::string>& vetor){
    static std::vector<std::string> dados;dados.clear();

    std::ofstream arquivo(nomeArquivo, std::ios::app);

    if (!arquivo.is_open()) {
        std::cerr << "Erro ao abrir o arquivo para escrita." << std::endl;
        return;
    }

    for (const std::string& linha : vetor) {
        arquivo << linha << std::endl;
    }

    arquivo.close();
    return dados;
}

std::vector<std::string> sobreescrever(const std::string& nomeArquivo, const std::vector<std::string>& vetor){
    static std::vector<std::string> dados;


    std::ofstream arquivo(nomeArquivo);

    if (!arquivo.is_open()) {
        std::cerr << "Erro ao abrir o arquivo para escrita." << std::endl;
        return;
    }

    for (const std::string& linha : vetor) {
        arquivo << linha << std::endl;
    }

    arquivo.close();
    return dados;
}