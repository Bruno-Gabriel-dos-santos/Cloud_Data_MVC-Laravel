#include <iostream>
#include <string>
#include <vector>


std::vector<std::string>* createVector(int size) {
    std::vector<std::string>* vec = new std::vector<std::string>(size);

    //std::vector<std::string>* dynamicVector = createVector(0); // Cria um vetor vazio

    //dynamicVector->push_back("10");
    


    //delete dynamicVector;

    return vec;
}



std::vector<std::string> gerencia_chaves(std::string entrada,std::string modo_de_operacao){

    
    static std::vector<std::string> banco_de_chaves_publicas;
    static std::vector<std::string> banco_de_chaves_privadas;
    static std::vector<std::string> comparador_saida_privadas;
    static std::vector<std::string> comparador_saida_publicas;
    static std::vector<std::string> nulo;nulo.clear();
    int comparacao=0;

    if(modo_de_operacao=="esvaziar_pu"){
        //realiza o esvaziamento da lista
        banco_de_chaves_publicas.clear();
    }
    if(modo_de_operacao=="adicionar_pu"){
        //realiza a adicao na lista
        banco_de_chaves_publicas.push_back(entrada);
    }
    if(modo_de_operacao=="transferir_pu"){
        //realiza a transferencia da lista
        return banco_de_chaves_publicas;
    }
    if(modo_de_operacao=="esvaziar_pr"){
        //realiza o esvaziamento da lista
        banco_de_chaves_privadas.clear();
    }
    if(modo_de_operacao=="adicionar_pr"){
        //realiza a adicao na lista
        banco_de_chaves_privadas.push_back(entrada);
    }
    if(modo_de_operacao=="transferir_pr"){
        //realiza a transferencia da lista
        return banco_de_chaves_privadas;
    }

    //modo de verificação = pega a chave oposta ao comparativo da verificacao 
    if(modo_de_operacao=="verificar_pu"){
        comparador_saida_privadas.clear();
        for (int i=0;i<banco_de_chaves_publicas.size();i++){
            comparacao=entrada.compare(banco_de_chaves_publicas[i]);
            if(comparacao==1){
                comparador_saida_privadas.push_back(banco_de_chaves_privadas[i]);
                return comparador_saida_privadas;
            }
        }
    comparador_saida_privadas.push_back("0");    
    return comparador_saida_privadas;    
    }

    if(modo_de_operacao=="verificar_pr"){
        comparador_saida_publicas.clear();
        for (int i=0;i<banco_de_chaves_privadas.size();i++){
            comparacao=entrada.compare(banco_de_chaves_privadas[i]);
            if(comparacao==1){
                comparador_saida_publicas.push_back(banco_de_chaves_publicas[i]);
                return comparador_saida_publicas;    
            }
        }
    comparador_saida_publicas.push_back("0");
    return comparador_saida_publicas;    
    }

    return nulo;
}


std::string pegar_chave_padrao(std::string entrada){
    std::string saida="";
    static std::vector<std::string> saida_;saida_.clear();
    int comparacao=entrada.compare("e58bzRop6+QUWE76ftk4qkwgDDE82iPfag2MmAfOvAg=");

    //PEGA A CHAVE PRIVADA CORRESPONDENTE A CHAVE PUBLICA QUE FOI  UTILIZADA NO MODO DE ERRO PADRAO
    
    if(comparacao == 1 ){
        saida="3dKtT7Fdb5rcVqQE3WWmUfT/+GrUfHqhXPeduFPHaik=";
        
    }else{
        
        saida_=gerencia_chaves(entrada,"verificar_pu");
        saida=saida_[0];
    }
    //saida =0 erro


    return saida;
}