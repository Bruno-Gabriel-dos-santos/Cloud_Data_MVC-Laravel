#include <iostream>
#include <string>
#include <vector>
#include "modulos/bs64_to_array.h"

int main(){

    std::string resultado="";
    std::string encoded_message = "ZXNzYSBlIHVtYSBtZW5zYWdlIC0gZW0gYmFzZSA7IGVtIGJhc2UgOyA2NA==";
    resultado = base64_decode(encoded_message);

    std::cout << "Decoded Message: " << resultado << std::endl;

    return 0;
}