#include <iostream>
#include <string>
#include <curl/curl.h>
#include <vector>
#include "modulos/curl_site.h"
#include "modulos/bs64_to_array.h"
#include "modulos/processamento_compra_venda.h"

/* MODELO DE ROTAS ->> SERVER

gerar_bloco_de_ordens,baixar_blocos

--modelo de info 

$caminho  =$_POST['rota'] ?? "0";
$inicio_  =$_POST['inicio'] ?? 0;// valor -10 ou atual de f_max referente a capacidade de alocacao do site 
$fim_ =99999999999999;
$senha    =$_POST['senha'] ?? "0";


MODELO AUXILIAR >> gerar chaves
0-> gera uma chave e volta a chave em bs64
1-> deleta as chaves
--modelo de infos
->$rota=$_POST['rota'] ?? "0";
$chave=$_POST['chave'] ?? "1";// ALTERAR PARA SUA CHAVE
*/


int main(){

    int rota=0;
    std::cout<<"Servidor de processamento rede Iroha modelo 1.1 modular teste \n\n inicie os modos de teste com as seguintes opcoes :"<<std::endl<<std::endl;
    std::cout<<"para gerar o bloco digite 1 , para baixar o bloco digite 2"<<std::endl;
    std::cin>>rota;
    if(rota==1){       
        std::string resultado="";
        std::string url_do_site="http://localhost/site_iroha/server.php";

        

        std::string parametros ="rota=gerar_bloco_de_ordens";

        //std::string parametros ="param1=value1&rota=gerar_bloco_de_ordens";
        resultado=curl_pegabloco(url_do_site,parametros);

        std::cout<<resultado;

    return 0;    
    }

    if(rota==2){
        std::string resultado="";
        std::string url_do_site="http://localhost/site_iroha/server.php";

        std::string parametros ="rota=baixar_blocos";

        //std::string parametros ="rota=gerar_bloco_de_ordens";

        //std::string parametros ="param1=value1&rota=gerar_bloco_de_ordens";
        resultado=curl_pegabloco(url_do_site,parametros);
        std::vector <std::string> vec_ordens;vec_ordens.push_back("");int ordem=0;



        // desmembra ordens
        int tamanho=resultado.size();
        for(int i=0;i!=tamanho;i++){
            if(resultado[i]=='~'){vec_ordens.push_back("");ordem++;}else{vec_ordens[ordem]=vec_ordens[ordem]+resultado[i];}
        }ordem--;
        //===============================================================================================
        // decodifica bs64
        std::vector <std::string> vec_ordens_decode;



        if(ordem>0){
            for(int i=0;i!=ordem;i++){
                vec_ordens_decode.push_back("");
                //vec_ordens_decode[i]=base64_decode(vec_ordens[i]);
                vec_ordens_decode[i]=base64_decode(vec_ordens[i]);
            }
        }
        //std::cout<<vec_ordens_decode[0];
        //================================================================================================
        //AQUI AS ORDENS JA ESTAO NO FORMATO CORRETO E É INICIADO O PROCESSAMENTO DAS COMPRAS E VENDAS
        std::vector<std::string> blocos_processados;
        blocos_processados=processamento_compra_venda(vec_ordens_decode);

    }





        // MODELO DE CICLO 
        // faz ciclo de 5min, gera o bloco , baixa o bloco
        // apos 144 ciclos deleta e troca as chaves criptografadas

        return 0;
}
