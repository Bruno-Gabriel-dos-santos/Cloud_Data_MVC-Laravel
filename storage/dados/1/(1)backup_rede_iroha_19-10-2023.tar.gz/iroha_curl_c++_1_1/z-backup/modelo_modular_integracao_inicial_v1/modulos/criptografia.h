#include <sodium.h>
#include <iostream>
#include <string>
#include <vector>

std::string descriptografa_assimetrica(std::string msg_,std::string chavePrivadaTexto,std::string chavePublicaTexto,std::string nonceTexto){
    std::string saida="";

    if (sodium_init() < 0) {
        std::cerr << "Erro ao inicializar o libsodium." << std::endl;
        
    }
    //==================================================================================================//
    // Converter a chave privada, chave pública e nonce de texto para vetores de bytes
    std::vector<unsigned char> chavePrivada(crypto_box_SECRETKEYBYTES);
    std::vector<unsigned char> chavePublica(crypto_box_PUBLICKEYBYTES);
    std::vector<unsigned char> nonce(crypto_box_NONCEBYTES);

    if (sodium_hex2bin(chavePrivada.data(), chavePrivada.size(), chavePrivadaTexto.c_str(), chavePrivadaTexto.length(), nullptr, nullptr, nullptr) < 0 ||
        sodium_hex2bin(chavePublica.data(), chavePublica.size(), chavePublicaTexto.c_str(), chavePublicaTexto.length(), nullptr, nullptr, nullptr) < 0 ||
        sodium_hex2bin(nonce.data(), nonce.size(), nonceTexto.c_str(), nonceTexto.length(), nullptr, nullptr, nullptr) < 0) {
        std::cerr << "Erro ao converter chaves ou nonce de texto para bytes." << std::endl;
        
    }

    // Buffer para a mensagem descriptografada
    std::vector<unsigned char> mensagemBuffer(msg_.size());

    // Descriptografar a mensagem usando a chave privada e pública
    if (crypto_box_open_easy(mensagemBuffer.data(), reinterpret_cast<const unsigned char*>(msg_.c_str()), msg_.size(), nonce.data(), chavePublica.data(), chavePrivada.data()) != 0) {
        std::cerr << "Erro ao descriptografar a mensagem." << std::endl;
        
    }

    // Converter a mensagem descriptografada para uma string
    saida.assign(reinterpret_cast<char*>(mensagemBuffer.data()), mensagemBuffer.size());

    // Limpando os dados sensíveis
    sodium_memzero(chavePrivada.data(), chavePrivada.size());
    sodium_memzero(chavePublica.data(), chavePublica.size());
    sodium_memzero(nonce.data(), nonce.size());

    return saida;
}


std::string descriptografa_simetrica(const std::string& mensagemCriptografada, const std::string& chaveSimetrica){
 
    if (sodium_init() < 0) {
        std::cerr << "Erro ao inicializar o libsodium." << std::endl;
        return "";
    }

    if (chaveSimetrica.size() != crypto_secretbox_KEYBYTES) {
        std::cerr << "Chave simétrica inválida." << std::endl;
        return "";
    }

    // Converter a mensagem criptografada de formato hexadecimal para bytes
    std::vector<unsigned char> mensagemCriptografadaBytes(mensagemCriptografada.size() / 2);
    sodium_hex2bin(mensagemCriptografadaBytes.data(), mensagemCriptografadaBytes.size(), mensagemCriptografada.c_str(), mensagemCriptografada.size(), nullptr, nullptr, nullptr);

    std::vector<unsigned char> nonce(crypto_secretbox_NONCEBYTES);
    std::vector<unsigned char> mensagemDescriptografada(mensagemCriptografadaBytes.size() - crypto_secretbox_MACBYTES);

    // Extrair o nonce dos primeiros bytes da mensagem criptografada
    std::copy(mensagemCriptografadaBytes.begin(), mensagemCriptografadaBytes.begin() + nonce.size(), nonce.begin());

    if (crypto_secretbox_open_easy(mensagemDescriptografada.data(), mensagemCriptografadaBytes.data() + nonce.size(), mensagemCriptografadaBytes.size() - nonce.size(), nonce.data(), reinterpret_cast<const unsigned char*>(chaveSimetrica.c_str())) != 0) {
        std::cerr << "Erro ao descriptografar a mensagem." << std::endl;
        return "";
    }

    return std::string(reinterpret_cast<const char*>(mensagemDescriptografada.data()), mensagemDescriptografada.size());


}


std::string criptografa_simetrica(const std::string& mensagem){
    

    if (sodium_init() < 0) {
        std::cerr << "Erro ao inicializar o libsodium." << std::endl;
        
    }
    
    const size_t chaveSimetricaTamanho = crypto_secretbox_KEYBYTES;
    std::vector<unsigned char> chaveSimetrica(chaveSimetricaTamanho);

    randombytes_buf(chaveSimetrica.data(), chaveSimetrica.size());

    std::vector<unsigned char> nonce(crypto_secretbox_NONCEBYTES);
    std::vector<unsigned char> mensagemCriptografada(mensagem.size() + crypto_secretbox_MACBYTES);

    randombytes_buf(nonce.data(), nonce.size());

    if (crypto_secretbox_easy(mensagemCriptografada.data(), reinterpret_cast<const unsigned char*>(mensagem.c_str()), mensagem.size(), nonce.data(), chaveSimetrica.data()) != 0) {
        std::cerr << "Erro ao criptografar a mensagem." << std::endl;
        return "";
    }

    // Concatenar nonce e mensagem criptografada para formar a saída
    std::vector<unsigned char> saida(nonce.size() + mensagemCriptografada.size());
    std::copy(nonce.begin(), nonce.end(), saida.begin());
    std::copy(mensagemCriptografada.begin(), mensagemCriptografada.end(), saida.begin() + nonce.size());

    // Converter a saída para uma string em formato hexadecimal
    std::string saidaHex;
    sodium_bin2hex(saidaHex.data(), saidaHex.size(), saida.data(), saida.size());




    return saidaHex;
}