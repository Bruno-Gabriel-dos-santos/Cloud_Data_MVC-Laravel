#include <iostream>
#include <string>

std::string pegar_chave_padrao(std::string entrada){
    std::string saida="";

    //PEGA A CHAVE PRIVADA CORRESPONDENTE A CHAVE PUBLICA QUE FOI UTILIZADA



    return saida;
}