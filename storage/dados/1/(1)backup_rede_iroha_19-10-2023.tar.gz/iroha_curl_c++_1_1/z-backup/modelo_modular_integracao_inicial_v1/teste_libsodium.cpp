#include <sodium.h>
#include <iostream>
#include <string>
#include <vector>

int main() {
    if (sodium_init() < 0) {
        std::cerr << "Erro ao inicializar o libsodium." << std::endl;
        return 1;
    }
    //==================================================================================================//
    // Chave pública em formato de texto
    std::string chavePublicaTexto = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    // Nonce em formato de texto
    std::string nonceTexto = "0123456789abcdef0123456789abcdef";


    // Converter a chave pública de texto para um vetor de bytes
    std::vector<unsigned char> chavePublica(crypto_box_PUBLICKEYBYTES);
    if (sodium_hex2bin(chavePublica.data(), chavePublica.size(), chavePublicaTexto.c_str(), chavePublicaTexto.length(), nullptr, nullptr, nullptr) < 0) {
        std::cerr << "Erro ao converter a chave pública de texto para bytes." << std::endl;
        return 1;
    }
    // Converter o nonce de texto para um vetor de bytes
    std::vector<unsigned char> nonce(crypto_box_NONCEBYTES);
    if (sodium_hex2bin(nonce.data(), nonce.size(), nonceTexto.c_str(), nonceTexto.length(), nullptr, nullptr, nullptr) < 0) {
        std::cerr << "Erro ao converter o nonce de texto para bytes." << std::endl;
        return 1;
    }
    //==================================================================================================//
    // Gere um par de chaves assimétricas
    unsigned char publicKey[crypto_box_PUBLICKEYBYTES];
    unsigned char privateKey[crypto_box_SECRETKEYBYTES];
    crypto_box_keypair(publicKey, privateKey);

    // Dados criptografados e buffer para dados descriptografados
    std::string mensagem_original = "Mensagem secreta";
    std::vector<unsigned char> mensagem_criptografada(crypto_box_SEALBYTES + mensagem_original.size());
    std::vector<unsigned char> mensagem_descriptografada(mensagem_original.size());

    // Criptografar a mensagem usando a chave pública
    crypto_box_seal(mensagem_criptografada.data(), reinterpret_cast<const unsigned char*>(mensagem_original.c_str()), mensagem_original.size(), publicKey);

    // Descriptografar a mensagem usando a chave privada
    if (crypto_box_seal_open(mensagem_descriptografada.data(), mensagem_criptografada.data(), mensagem_criptografada.size(), publicKey, privateKey) != 0) {
        std::cerr << "Erro ao descriptografar a mensagem." << std::endl;
        return 1;
    }

    // Converta os dados descriptografados de volta para uma string
    std::string mensagem_final(reinterpret_cast<char*>(mensagem_descriptografada.data()), mensagem_descriptografada.size());

    // Imprima a mensagem original e a mensagem descriptografada
    std::cout << "Mensagem original: " << mensagem_original << std::endl;
    std::cout << "Mensagem descriptografada: " << mensagem_final << std::endl;

    return 0;
}
