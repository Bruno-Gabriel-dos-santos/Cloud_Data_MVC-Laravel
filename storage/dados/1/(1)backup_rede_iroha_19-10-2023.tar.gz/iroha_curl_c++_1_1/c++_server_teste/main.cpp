#include <iostream>
#include <string>
#include <curl/curl.h>

int main() {
    CURL *curl;
    CURLcode res;
    std::string response;

    // Inicializar a biblioteca cURL
    curl_global_init(CURL_GLOBAL_ALL);

    // Inicializar o objeto cURL
    curl = curl_easy_init();
    if (curl) {
        // Configurar a URL do serviço PHP que retorna o JSON
        std::string url = "http://localhost/site_iroha/server.php";

        // Configurar a URL para o cURL
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

        // Configurar a opção para seguir redirecionamentos (se necessário)
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

        // Definir a função para receber os dados (resposta JSON)
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, [](char *data, size_t size, size_t nmemb, std::string *output) {
            size_t totalSize = size * nmemb;
            output->append(data, totalSize);
            return totalSize;
        });
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

        // Executar a solicitação HTTP
        res = curl_easy_perform(curl);

        // Verificar erros
        if (res != CURLE_OK) {
            std::cerr << "Erro na solicitação cURL: " << curl_easy_strerror(res) << std::endl;
        } else {
            // A resposta JSON está em 'response', você pode processá-la aqui
            std::cout << "Resposta JSON: " << response << std::endl;
        }

        // Limpar
        curl_easy_cleanup(curl);
    }

    // Finalizar a biblioteca cURL
    curl_global_cleanup();

    return 0;
}

