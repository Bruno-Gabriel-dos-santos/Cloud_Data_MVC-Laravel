#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>

int main() {
    // Criação do socket TCP
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        std::cerr << "Erro ao criar o socket" << std::endl;
        return 1;
    }

    // Configuração do endereço de destino
    struct sockaddr_in serverAddress;
    std::memset(&serverAddress, 0, sizeof(serverAddress));
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(12345); // Porta do servidor
    if (inet_pton(AF_INET, "127.0.0.1", &(serverAddress.sin_addr)) <= 0) {
        std::cerr << "Erro ao configurar o endereço de destino" << std::endl;
        return 1;
    }

    // Conexão com o servidor
    if (connect(sockfd, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) {
        std::cerr << "Erro ao estabelecer a conexão com o servidor" << std::endl;
        return 1;
    }

    // Envio da mensagem
    std::string message = "Olá, servidor!";
    if (send(sockfd, message.c_str(), message.size(), 0) == -1) {
        std::cerr << "Erro ao enviar a mensagem" << std::endl;
        return 1;
    }

    // Recebimento da resposta
    char buffer[1024];
    int numBytes = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
    if (numBytes == -1) {
        std::cerr << "Erro ao receber a resposta" << std::endl;
        return 1;
    }
    buffer[numBytes] = '\0';

    std::cout << "Resposta do servidor: " << buffer << std::endl;

    // Fechamento do socket
    close(sockfd);

    return 0;
}
