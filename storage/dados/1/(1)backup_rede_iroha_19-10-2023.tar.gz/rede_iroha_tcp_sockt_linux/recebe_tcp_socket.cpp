#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>

int main() {
    // Criação do socket TCP
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        std::cerr << "Erro ao criar o socket" << std::endl;
        return 1;
    }

    // Configuração do endereço de escuta
    struct sockaddr_in serverAddress;
    std::memset(&serverAddress, 0, sizeof(serverAddress));
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(12345); // Porta de escuta
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // Associação do socket ao endereço de escuta
    if (bind(sockfd, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) {
        std::cerr << "Erro ao associar o socket ao endereço" << std::endl;
        return 1;
    }

    // Escuta por conexões de clientes
    if (listen(sockfd, 10) == -1) {
        std::cerr << "Erro ao escutar por conexões" << std::endl;
        return 1;
    }

    // Aceita a conexão do cliente
    struct sockaddr_in clientAddress;
    socklen_t clientAddressLength = sizeof(clientAddress);
    int clientfd = accept(sockfd, (struct sockaddr*)&clientAddress, &clientAddressLength);
    if (clientfd == -1) {
        std::cerr << "Erro ao aceitar a conexão" << std::endl;
        return 1;
    }

    // Recebimento da mensagem do cliente
    char buffer[1024];
    int numBytes = recv(clientfd, buffer, sizeof(buffer) - 1, 0);
    if (numBytes == -1) {
        std::cerr << "Erro ao receber a mensagem" << std::endl;
        return 1;
    }
    buffer[numBytes] = '\0';

    std::cout << "Mensagem recebida do cliente: " << buffer << std::endl;

    // Envio da resposta ao cliente
    std::string response = "Mensagem recebida com sucesso!";
    if (send(clientfd, response.c_str(), response.size(), 0) == -1) {
        std::cerr << "Erro ao enviar a resposta" << std::endl;
        return 1;
    }

    // Fechamento dos sockets
    close(clientfd);
    close(sockfd);

    return 0;
}
