<?php

// Configurações do servidor
$host = 'localhost';  // Endereço IP ou nome do host
$port = 12345;       // Porta do servidor

// Criação do socket TCP
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($socket === false) {
    echo "Erro ao criar o socket: " . socket_strerror(socket_last_error()) . "\n";
    exit(1);
}

// Associa o socket ao endereço e porta do servidor
if (socket_bind($socket, $host, $port) === false) {
    echo "Erro ao associar o socket ao endereço: " . socket_strerror(socket_last_error($socket)) . "\n";
    exit(1);
}

// Escuta por conexões de clientes
if (socket_listen($socket) === false) {
    echo "Erro ao escutar por conexões: " . socket_strerror(socket_last_error($socket)) . "\n";
    exit(1);
}

echo "Aguardando conexões...\n";

// Aceita a conexão do cliente
$clientSocket = socket_accept($socket);
if ($clientSocket === false) {
    echo "Erro ao aceitar a conexão: " . socket_strerror(socket_last_error($socket)) . "\n";
    exit(1);
}

echo "Cliente conectado. Aguardando mensagem...\n";

// Recebe a mensagem do cliente
$clientMessage = socket_read($clientSocket, 1024);
if ($clientMessage === false) {
    echo "Erro ao receber mensagem do cliente: " . socket_strerror(socket_last_error($clientSocket)) . "\n";
    exit(1);
}

echo "Mensagem recebida do cliente: " . $clientMessage . "\n";

// Prepara a mensagem de resposta
$response = "Mensagem recebida com sucesso!";

// Envia a resposta para o cliente
if (socket_write($clientSocket, $response, strlen($response)) === false) {
    echo "Erro ao enviar mensagem para o cliente: " . socket_strerror(socket_last_error($clientSocket)) . "\n";
    exit(1);
}

echo "Resposta enviada para o cliente.\n";

// Fecha a conexão com o cliente
socket_close($clientSocket);

// Fecha o socket do servidor
socket_close($socket);

?>
