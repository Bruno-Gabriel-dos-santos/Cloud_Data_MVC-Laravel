<?php
	// VERSÃO 1.1
	
	$dados   =  $_POST['dados'] ?? "000000";
	
	

	
	
	
    

    // Texto a ser criptografado
    $plaintext = $dados;// AQUI VAI O MODELO DO BLOCO

    for($i=0;$i!=1100;$i++){

        // Gera um nonce (número único usado uma vez)
        $key = sodium_crypto_secretbox_keygen(); // SENHA DO BLOCO
        $nonce ="";
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES); // NONCE DO BLOCO
        $nonce_segurador = "";
        $nonce_segurador = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $nc_s_64="";
        $nc_s_64=base64_encode($nonce_segurador);
        $plaintext2 = "";
        $plaintext2=$plaintext.$nc_s_64;
        // Criptografa o texto
        $ciphertext = sodium_crypto_secretbox($plaintext, $nonce, $key);

        // Decifra o texto
        //$decrypted = sodium_crypto_secretbox_open($ciphertext, $nonce, $key);

        $nonce_=base64_encode($nonce);
        $cp    =base64_encode($ciphertext);
        $ky    =base64_encode($key);
        $saida=$cp."@".$nonce_."@".$ky;
        
        echo $saida;echo "<br>";
    }
    //echo $plaintext;echo "<br><br>";echo $ciphertext;echo "<br><br>";echo $decrypted;







?>
