#include <iostream>
#include <string>
#include <vector>
//#include "bs64_to_array.h" //<- retirar na produção !!!
#include "criptografia.h"
#include "banco_de_chaves_privadas.h"


std::vector<std::string> processamento_compra_venda( std::vector<std::string> entrada ){

    
    static std::vector<std::string>saida;saida.clear();
    
    std::string chavePrivada_padrao="";
    int quantia_de_campos=1;int tamanho_do_campo=0;//quantia_de_campos=entrada.size();
    std::string valor_ordem="";
    std::string conta="";
    std::string conta_destino="";
    std::string nome_servidor="";
    std::string senha_criptografada="";//=ency_
    std::string nonce_da_chave="";
    std::string chave_publica_site="";
    std::string chave_publica_server="";
    //===============================================================//
    std::string senha_bs_decode="";
    std::string nonce_bs_decode="";
    std::string chavePublicaSite_bs_decode="";
    std::string chavePrivada_padrao_bs_decode="";
    std::string senha_descriptografada="";
    std::string senha_descriptografada_bs_decode="";
    
    // faz o loop com a quantidade de vetores disponiveis
    
    std::string comparativo="";int contador=0;
    for(int i=0;i!=quantia_de_campos;i++){
        tamanho_do_campo=entrada[i].size();
        comparativo=entrada[i];
        for(int i2=0;i2<tamanho_do_campo;i2++){
            if(comparativo[i2]=='@'){contador++;}else{
                
                if(contador==0){valor_ordem=valor_ordem+comparativo[i2];}
                if(contador==1){conta=conta+comparativo[i2];}
                if(contador==2){conta_destino=conta_destino+comparativo[i2];}
                if(contador==3){nome_servidor=nome_servidor+comparativo[i2];}
                if(contador==4){senha_criptografada=senha_criptografada+comparativo[i2];}
                if(contador==5){nonce_da_chave=nonce_da_chave+comparativo[i2];}
                if(contador==6){chave_publica_site=chave_publica_site+comparativo[i2];}
                if(contador==7){chave_publica_server=chave_publica_server+comparativo[i2];}

            }}
        // REALIZAR DECODE DO NONCE E DA SENHA 
        senha_bs_decode=base64_decode(senha_criptografada);
        nonce_bs_decode=base64_decode(nonce_da_chave);
        chavePublicaSite_bs_decode=base64_decode(chave_publica_site);
        
        chavePrivada_padrao=pegar_chave_padrao(chave_publica_server);
        chavePrivada_padrao_bs_decode=base64_decode(chavePrivada_padrao);
        
        // REALIZA A DESCRIPTOGRAFIA DA SENHA
        senha_descriptografada=descriptografa_assimetrica(senha_criptografada,chavePrivada_padrao,chave_publica_site,nonce_da_chave);
        senha_descriptografada_bs_decode=base64_decode(senha_descriptografada);
        // std::cout<<senha_descriptografada;
        
        //COMECA A ABERTURA DO BLOCO E VERIFICA SE O VALOR E MAIOR QUE 0 E SE A SENHA ABRE O BLOCO
        
        //FAZ A TRANSFERENCIA E GERA O CERTIFICADO DE PROCESSAMENTO

        //INCLUI O CERTIFICADO EM UM VETOR PARA SER ENVIADO AOS OUTROS NOS DA REDE IROHA
    }

    // descodifica usando bs64

    // pega os dados de transferencia

    // descriptografa a senha usando as chaves cadastradas

    // faz a transferencia de moedas

    // faz a insercao da transferencia no livro de transferencias

    return saida;
}