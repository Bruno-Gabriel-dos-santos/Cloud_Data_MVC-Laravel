#include <sodium.h>
#include <iostream>
#include <string>
#include <vector>
#include <cstring>

std::string descriptografa_assimetrica(std::string msg_,std::string chavePrivadaTexto,std::string chavePublicaTexto,std::string nonceTexto){
        
        
        std::string url_do_site="http://localhost/descriptografia/assimetrica.php";
       

        std::string parametros ="nonce=";

        parametros=parametros+nonceTexto;
        parametros=parametros+"&publica=";
        parametros=parametros+chavePublicaTexto;
        parametros=parametros+"&privada=";
        parametros=parametros+chavePrivadaTexto;
        parametros=parametros+"&msg=";
        parametros=parametros+msg_;

        //parametros ="nonce=&publica=&privada=";
        //std::cout<<chavePublicaTexto<<parametros;
        std::string resultado="";
        resultado=curl_pegabloco(url_do_site,parametros);

        //std::cout<<"\n\n"<<resultado;

        return resultado;
}


std::string descriptografa_simetrica(const std::string& mensagemCriptografada, const std::string& chaveSimetrica){
    
    std::string saida="";
    return saida; 
}


std::string criptografa_simetrica(const std::string& mensagem){
    std::string saida="";
    return saida; 

    
}