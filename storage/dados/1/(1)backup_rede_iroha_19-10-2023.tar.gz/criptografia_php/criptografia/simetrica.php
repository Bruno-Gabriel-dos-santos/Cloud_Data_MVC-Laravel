<?php

	// CRIPTOGRAFIA SIMETRICA

$msg_   =  $_POST['msg'] ?? 0;
$senha_ =  $_POST['senha'] ?? 0;
$nonce_ =  $_POST['nonce'] ?? 0;

$msg = str_replace(" ", "+", $msg_);
$key = str_replace(" ", "+", $senha_);
$nonce = str_replace(" ", "+", $nonce_);


$saida_ =  sodium_crypto_secretbox($msg, $nonce, $key);

$saida= base64_encode($saida_);

echo $saida;


?>
