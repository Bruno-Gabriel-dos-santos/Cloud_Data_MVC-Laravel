<?php
	// DESCRIPTOGRAFIA SIMETRICA
$msg_   =  $_POST['msg'] ?? 0;
$senha_ =  $_POST['senha'] ?? 0;
$nonce_ =  $_POST['nonce'] ?? 0;

$msg0   = str_replace(" ", "+", $msg_);
$key0   = str_replace(" ", "+", $senha_);
$nonce0 = str_replace(" ", "+", $nonce_);

$msg    = base64_decode($msg0);
$key    = base64_decode($key0);
$nonce  = base64_decode($nonce0);

$saida_ = sodium_crypto_secretbox_open($msg, $nonce, $key);

$saida= base64_encode($saida_);

echo $saida;



?>
