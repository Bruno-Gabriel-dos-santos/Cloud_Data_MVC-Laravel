<?php

	// DESCRIPTOGRAFIA ASSIMETRICA

$msg_          =  $_POST['msg'] ?? 0;
$chave_privada_ =  $_POST['privada'] ?? 0;
$chave_publica_ =  $_POST['publica'] ?? 0;
$nonce_         =  $_POST['nonce'] ?? 0;

$msg = str_replace(" ", "+", $msg_);
$chave_privada = str_replace(" ", "+", $chave_privada_);
$chave_publica = str_replace(" ", "+", $chave_publica_);
$nonce = str_replace(" ", "+", $nonce_);

//echo "msg: $msg  chave_privada: $chave_privada chave_publica: $chave_publica nonce: $nonce";

// $msg="5G0lJOB8fTz/YYu2/c2x+JA=";
//  $chave_privada="3dKtT7Fdb5rcVqQE3WWmUfT/+GrUfHqhXPeduFPHaik=";
//  $chave_publica="gz+VE18WMB7pi6v4vNB1PKbEp7uN87UMQkkXSTTZgSQ=";
//  $nonce="kZrX2Xi4dwGof4MtmywQtN01j7wbHVdm";

$msg_decode    =base64_decode($msg);
$publica_decode=base64_decode($chave_publica);
$privada_decode=base64_decode($chave_privada);
$nonce_decode  =base64_decode($nonce);


$key= sodium_crypto_box_keypair_from_secretkey_and_publickey($privada_decode,$publica_decode);

$saida = sodium_crypto_box_open($msg_decode, $nonce_decode, $key);

$saida_=base64_encode($saida);
  
echo $saida_;


?>
