<?php
// CHAVE DE ACESSO PARA INICIAR A JUNCAO E COMPRESSAO DAS TRANSACOES EM UM UNICO ARQUIVO = 'DBFIBJD[OUQWUSDBAjbsdhiasjdbjabsdiyqwgdyb'
// CHAVE PARA BAIXAR AS ORDENS EM UM UNINCO ARQUIVO [BAIXAR]='LAST','ALL','NUMBER-10?'

$caminho=$_POST['rota'];
$instrucao=$_POST['instrucao'];

if($rota=='gerar_bloco_de_ordens'){}

if($rota=='baixar_blocos'){}

if($rota=='inserir_chaves_criptografadas'){}

echo "chave de criptografia publica atual : 'jdsjsadjfsdnfjnsdjnfjsndkjfnsdj'";// usar para criptografar a ordem de compra-venda











?>