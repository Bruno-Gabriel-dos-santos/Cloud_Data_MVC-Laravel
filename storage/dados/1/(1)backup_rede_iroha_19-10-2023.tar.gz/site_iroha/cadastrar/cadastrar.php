<?php

$curl=curl_init();

curl_setopt_array($curl,[
    CURLOPT_URL=>'https://www.google.com/recaptcha/api/siteverify',
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_CUSTOMREQUEST=>'POST',
    CURLOPT_POSTFIELDS=>[
        'secret'  =>'6LfOec0mAAAAAJlvvoQMUZ1gBMpEsYpe6nMCSx-N',
        'response'=>$_POST['g-recaptcha-response'] ?? ''
    ]
]);

$response=curl_exec($curl);

curl_close($curl);

$response_array= json_decode($response,true);

$resultado_captcha=$response_array['success'] ?? 'false';

if($resultado_captcha== true){}else{header("Location: http://localhost/site_iroha/cadastrar/index.php?status-cadastro=erro-1");}

include'../functions/conecxao.php';

$nick  = $_POST['nick'] ?? 0;
$senha = $_POST['senha'] ?? 0;
$email = $_POST['email'] ?? 0;

$nick_hash =hash('sha512',$nick);
$senha_hash=hash('sha512',$senha);

$nick=hash('sha512',$nick);
$senha=hash('sha512',$senha);

$query="SELECT nick FROM usuario WHERE nick = '$nick';";


$resultado = mysqli_query($mysqli, $query);

if ($resultado != NULL && mysqli_num_rows($resultado) > 0) {
    // Usuário encontrado, redireciona para a página 'entrou.php'
    //pega as infos do usuario;;
    mysqli_close($mysqli);
    header("Location: http://localhost/site_iroha/cadastrar/index.php?status-cadastro=erro");
} else {
    // Usuário não encontrado, continua o processo de cadastro
    
}


$query="INSERT INTO usuario (nick,senha,email) values ('$nick','$senha','$email')";

if(mysqli_query($mysqli, $query)){
    
}else{
    mysqli_close($mysqli);
    header("Location: http://localhost/site_iroha/cadastrar/index.php?status-cadastro=erro");
}




mysqli_close($mysqli);


?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Cadastro Sucesso</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="../assets/logo_eternus_grande_discreto.png" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body class="d-flex flex-column h-100">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container px-5">
            <a class="navbar-brand" href="https://www.rede-iroha.com/home/">Rede Iroha</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/home/">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/comprar/">Comprar Moedas</a></li>
                    <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/contribuir/">Contribuir</a></li>
                    
                </ul>
            </div>
        </div>
    </nav>
        <br><br><h1 class="text-center fs-1">Cadastro realizado com sucesso</h1><br><br>
        
        <div class="w-75 bg-dark rounded-3">
            <div class="mt-3 bg-white">
                <p class="text-center fs-4"> O nick e senha que voce inseriu serao utilizados apenas para logar no site Rede_Iroha, abaixo estão os dados do seu bloco e senha cadastrados na Rede_Iroha.<br>
                Eles serão utilizados para validar as transferencias de moedas, compras na rede e na utilizacao e acesso das ferramentas na rede.</p>
            </div>
        </div>
    

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
