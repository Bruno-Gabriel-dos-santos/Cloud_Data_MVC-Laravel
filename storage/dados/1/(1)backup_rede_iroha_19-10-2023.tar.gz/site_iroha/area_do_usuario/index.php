
<?php 

include'../functions/verificar_loguin.php';

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Area do Usuario Rede_Iroha</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="../assets/logo_eternus_grande_discreto.png" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body class="d-flex flex-column h-100">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container px-5">
            <a class="navbar-brand" href="https://www.rede-iroha.com/home/">Rede Iroha</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/home/">Home</a></li>
                    
                     
                </ul>
            </div>
        </div>
    </nav>
        <br><br><h2 class="text-center fs-1 py-5">Bem vindo novamente a Rede_Iroha <?php $nick=$_POST['nick'];echo $nick; ?></h2><br><br>
        <nav class="navbar navbar-dark ">
            <div class="container px-5 w-75 mx-auto bg-dark rounded-3">
                <a class="navbar-brand" href="#nonastoffa">Menu de acesso rapido</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/buscador-iroha/">Terminal Rede-Iroha</a></li>
                        <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/contribuir/">Crie sites,blogs e conteudo para a rede Iroha</a></li>
                        <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/contribuir/">Contribuir com codigos para a rede</a></li>
                        <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/contribuir/">Ganhe Irohas sendo um Worker</a></li>
                        <li class="nav-item"><a class="nav-link" href="https://www.rede-iroha.com/comprar/">Comprar moedas Iroha</a></li>
                        
                        
                    </ul>
                </div>
            </div>
        </nav>

        <nav class="navbar navbar-dark ">
            <div class="container px-5 w-75 mx-auto bg-dark rounded-3">
                <a class="navbar-brand" href="#nonastoffa">Saldo e dados da conta</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarteste" aria-controls="navbarteste" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarteste">
                <div class="m-2 bg-white">
                            <p>um texto</p>
                        </div>
                </div>
            </div>
        </nav>

        <div class="w-75 bg-dark mx-auto rounded-3 mb-3">
            <div class="m-3 d-flex">
                <div class="rounded-3 bg-white">   
                    <p class="m-2 p-1 fs-5 font-italic"> Sua Conta Iroha esta com o nivel <?php echo"nivel";?>, sendo a pontuacao atual de <?php echo "x pontos"; ?>. Aumente o nivel de sua conta realizando transaçōes e participando na comunidade.</p>
                </div>
            </div>
        </div>

        

        <div class="w-75 bg-dark rounded-3 mx-auto">
        <div class="container  m-3 mx-auto">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Enviar moedas Iroha</h5>
                    <form>
                    <div class="form-group">
                        <label for="valor">Valor:</label>
                        <input type="text" class="form-control" id="valor" placeholder="Digite o valor">
                    </div>
                    <div class="form-group">
                        <label for="conta">Conta:</label>
                        <input type="text" class="form-control" id="conta" placeholder="Digite a conta">
                    </div>
                    <div class="form-group">
                        <label for="contaDestino">Conta de Destino:</label>
                        <input type="text" class="form-control" id="contaDestino" placeholder="Digite a conta de destino">
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha:</label>
                        <input type="password" class="form-control" id="senha" placeholder="Digite a senha">
                    </div>
                    <button type="submit" class="btn btn-primary mt-1">Enviar Ordem</button>
                    </form>
                </div>
            </div>
        </div>
        </div>
        

       
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
