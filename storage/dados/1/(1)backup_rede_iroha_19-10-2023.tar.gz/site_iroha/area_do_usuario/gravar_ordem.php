<?php
include '../functions/conecxao.php';

// UTILIZADO PARA GRAVAR A ORDEM NO BANCO DE DAODS MYSQL -->

$numero_de_bytes = 4;

$bytes_aleatorios = random_bytes($numero_de_bytes);

$numero_aleatorio = hexdec(bin2hex($bytes_aleatorios));

$min = 1;
$max = 10;
$rand_id = $min + ($numero_aleatorio % ($max - $min + 1));

$query="SELECT chave_publica, nonce FROM chaves_e_nonce where id='$rand_id';";

$resultado = mysqli_query($mysqli, $query);

if ($resultado != NULL && mysqli_num_rows($resultado) > 0) {
    // Obter o primeiro resultado da consulta
    $row = mysqli_fetch_assoc($resultado);
    $chave_publica = $row['chave_publica'];
    $nonce = $row['nonce'];
} else {
    // usa chave e nonce padrão
    $chave_publica = "ndiwedibwndpiuwndejnwojndiuwnedjnwodnweudn";
    $nonce = "wjbdbwoidmkwned[inwoednwndepjwndepnwdnw";
}
// TODAS AS ENTRADAS JA ESTAO EM BASE_64

$valor_ordem=$_POST['valor'];
$conta_destino=$_POST['destino'];
$chave_do_bloco=$_POST['chave_do_bloco'];// (chave?nonce)
$bloco_array=$_POST['bloco_array'];// LOCAL DA MATRIZ --> (numero_rede?numero_bloco?numero_conta)
$nome_do_servidor="WORKER_A_1";//-- MODIFICAR PARA O VALOR DA CONTA WORKER FORNECIDO NA CRIACAO DA CONTA IROHA E NOS ARQUIVOS DE CONFIGURACAO DO SERVIDOR


$nonce_ = base64_decode($nonce);
$chave_publica_ = base64_decode($chave_publica);

$key= sodium_crypto_box_keypair_from_secretkey_and_publickey($chavePrivada,$chavePublica);
$msg=$chave_do_bloco;
$encript = sodium_crypto_box($msg,$nonce,$key);

$arquivo_completo=$valor_ordem+"@"+$conta_destino+"@"+$nome_do_servidor+"@"+$bloco_array+"@"+$encript;

$arquivo_bs64=base64_encode($arquivo_completo);

$query="INSERT INTO `Ordens_de_compra_venda`(`id`, `arquivo_ordem_criptografado`, `nonce_criptografado`, `chave_publica_utilizada_criptografada`, `data_hora`, `dados_compra_venda`) VALUES (NULL,'$arquivo_bs64','$nonce','$chave_publica',NOW(),'E-IROHA-S-WORKER_A_1')";

$resultado_ = mysqli_query($mysqli, $query);

if($resultado_){

    mysqli_close($mysqli);

    echo "Sucesso na operacao";


}else{


mysqli_close($mysqli);

echo "Erro na operacao";

}






?>