<?php


$valor=10;
$nome="0,0000123123IROHA";

'<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post" >
	<input type="hidden" name="cmd" value="_cart">
	<input type="hidden" name="business" value="brunoute@icloud.com">
	<input type="hidden" name="lc" value="BR">
	<input type="hidden" name="item_name" value="';echo $nome;echo '">
	<input type="hidden" name="amount" value="';echo $valor;echo '">
	<input type="hidden" name="currency_code" value="BRL">
	<input type="hidden" name="button_subtype" value="products">
	<input type="hidden" name="no_note" value="0">
	<input type="hidden" name="add" value="1">
	<input type="hidden" name="bn" value="PP-ShopCartBF:btn_cart_LG.gif:NonHostedGuest">
	<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_cart_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
	<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">












?>