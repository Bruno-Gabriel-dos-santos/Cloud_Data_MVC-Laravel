<?php
include '../functions/conecxao.php';

$rota=$_POST['rota'] ?? "0";
$chave=$_POST['chave'] ?? "0";

echo $rota;echo"\n";echo $chave;echo"\n";

// INSIRA ABAIXO A SUA CHAVE
if($chave=="0"){

}else{ echo "5";die();}

if($rota==1){

    $query = "DELETE FROM `chaves_e_nonce`;";

    // Executa a consulta
    $resultado = mysqli_query($mysqli, $query);
    
    // Verifica se a operação foi bem-sucedida
    if ($resultado) {
        echo "1";
        mysqli_close($mysqli);
        exit;
    } else {
        echo "0";
        mysqli_close($mysqli);
        exit;
    }

}

// GERA AS CHAVES PUBLICA E PRIVADAS

    
    $chaveprincipal = sodium_crypto_box_keypair();  

    $chavePublica  = sodium_crypto_box_publickey($chaveprincipal);
    $chavePrivada  = sodium_crypto_box_secretkey($chaveprincipal);

    $nonce = random_bytes(SODIUM_CRYPTO_BOX_NONCEBYTES);
    echo "l-0";
    $ch_pub_bs64= base64_encode($chavePublica);
    $nonc_bs64=base64_encode($nonce);

        echo "l1";
    $query="INSERT INTO `chaves_e_nonce`(`id`, `chave_publica`, `nonce`) VALUES (NULL,'[value-2]','[value-3]');";

    $resultado_ = mysqli_query($mysqli, $query);
    echo "l2";
    if($resultado_){

        mysqli_close($mysqli);

        echo "1";
        echo $nonc_bs64;


    }else{


    mysqli_close($mysqli);

    echo "0";

    }









?>