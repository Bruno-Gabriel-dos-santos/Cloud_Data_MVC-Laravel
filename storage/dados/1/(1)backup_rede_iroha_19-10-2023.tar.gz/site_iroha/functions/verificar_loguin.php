<?php

include'../functions/conecxao.php';

$nick  = $_POST['nick'] ?? 0;
$senha = $_POST['senha'] ?? 0;

$query="SELECT nick, senha FROM usuario WHERE nick = '$nick' AND senha = '$senha';";


$resultado = mysqli_query($mysqli, $query);

if ($resultado != NULL && mysqli_num_rows($resultado) > 0) {
    // Usuário encontrado, redireciona para a página 'entrou.php'
    //pega as infos do usuario;;
    
} else {
    // Usuário não encontrado, redireciona para a página 'falhou.php'
    mysqli_close($mysqli);
    header("Location: http://localhost/site_iroha/loguin/?status=erro");
    
}



mysqli_close($mysqli);






?>